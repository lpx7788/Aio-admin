import React from 'react'
import { Row, Card } from 'antd'
export default class ApplicationDetail extends React.Component {
  componentDidMount() {
 
  }
  render() {
    return (
      <Row>
        <Card>
         <div>ApplicationDetail</div>
        </Card>
      </Row>
    )
  }
}
