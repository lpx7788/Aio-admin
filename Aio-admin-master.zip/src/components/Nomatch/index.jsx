import React from 'react'

export default class NoMatch extends React.Component {
    render() {
        return <div>Not Found</div>
    }
}

