import React from 'react'
import { Row, Card } from 'antd'
export default class Home extends React.Component {
  componentDidMount() {
 
  }
  render() {
    return (
      <Row>
        <Card>
         <div>table42423432</div>
        </Card>
      </Row>
    )
  }
}
